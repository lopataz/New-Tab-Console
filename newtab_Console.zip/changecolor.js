document.addEventListener("DOMContentLoaded", function(event) {

	chrome.storage.sync.get({
		favoriteColor: '000000'
	  }, function(items) {
		document.body.style.background = "#"+items.favoriteColor;
		if(items.favoriteColor == "000000") document.getElementById("typingConsole").style.color = "#fff";
	  });
});