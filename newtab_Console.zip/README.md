# New-Tab-Console

New tab console lets you have a console on Chrome "new tabs" opening.


Available commands: (shift Enter(x2) on a new line):

save (Saves current display)  
erase (Erases last save)  
restore (Loads the save)  
clear (Clears whole console)  
visit url (Goes to the specified url)  
help (Displays the current commands)  